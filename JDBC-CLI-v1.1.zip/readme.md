This is an DIR for JDBC-CLI.
